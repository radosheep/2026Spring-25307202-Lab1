if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Login_Params {
    bundleName?: string;
}
import { LoginInfo } from "@bundle:ohos.samples.etsappaccountmanager/entry/ets/common/LoginInfo";
import { NavigationBar } from "@bundle:ohos.samples.etsappaccountmanager/entry/ets/common/NavigationBar";
class Login extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__bundleName = new ObservedPropertySimplePU((this.getUIContext().getRouter().getParams() as Record<string, string>)['bundleName'], this, "bundleName");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Login_Params) {
        if (params.bundleName !== undefined) {
            this.bundleName = params.bundleName;
        }
    }
    updateStateVars(params: Login_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__bundleName.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__bundleName.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __bundleName: ObservedPropertySimplePU<string>;
    get bundleName() {
        return this.__bundleName.get();
    }
    set bundleName(newValue: string) {
        this.__bundleName.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Login.ets(25:5)", "entry");
            Column.width('100%');
            Column.height('100%');
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavigationBar(this, { title: { "id": 16777263, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" }, flag: true, url: 'pages/Index' }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Login.ets", line: 26, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: { "id": 16777263, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                            flag: true,
                            url: 'pages/Index'
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "NavigationBar" });
        }
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new LoginInfo(this, { bundleName: this.bundleName }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Login.ets", line: 28, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            bundleName: this.bundleName
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        bundleName: this.bundleName
                    });
                }
            }, { name: "LoginInfo" });
        }
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Login";
    }
}
registerNamedRoute(() => new Login(undefined, {}), "", { bundleName: "ohos.samples.etsappaccountmanager", moduleName: "entry", pagePath: "pages/Login", pageFullPath: "entry/src/main/ets/pages/Login", integratedHsp: "false", moduleType: "followWithHap" });
