if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface RegisterInfo_Params {
    passWord?: string;
    username?: string;
    emailInfo?: string;
    signature?: string;
    confirmPassword?: string;
    dataSet?: MyDataSource;
    bundleName?: string;
    storage?: AccountData;
    accountModel?: AccountModel;
}
import Logger from "@bundle:ohos.samples.etsappaccountmanager/entry/ets/model/Logger";
import { AccountData } from "@bundle:ohos.samples.etsappaccountmanager/entry/ets/model/AccountData";
import { AccountModel } from "@bundle:ohos.samples.etsappaccountmanager/entry/ets/model/AccountModel";
class BasicDataSource implements IDataSource {
    private listeners: DataChangeListener[] = [];
    public totalCount() {
        return 0;
    }
    public getData(index: number): DataArray {
        return new DataArray();
    }
    registerDataChangeListener(listener: DataChangeListener) {
        if (this.listeners.indexOf(listener) < 0) {
            this.listeners.push(listener);
        }
    }
    unregisterDataChangeListener(listener: DataChangeListener) {
        const pos = this.listeners.indexOf(listener);
        if (pos >= 0) {
            this.listeners.splice(pos, 1);
        }
    }
    notifyDataReload() {
        this.listeners.forEach(listener => {
            listener.onDataReloaded();
        });
    }
    notifyDataAdd(index: number) {
        this.listeners.forEach(listener => {
            listener.onDataAdd(index);
        });
    }
    notifyDataChange(index: number) {
        this.listeners.forEach(listener => {
            listener.onDataChange(index);
        });
    }
    notifyDataDelete(index: number) {
        this.listeners.forEach(listener => {
            listener.onDataDelete(index);
        });
    }
    notifyDataMove(from: number, to: number) {
        this.listeners.forEach(listener => {
            listener.onDataMove(from, to);
        });
    }
}
class DataArray {
    text: Resource = { "id": 16777235, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" };
    inputType: InputType = InputType.Normal;
    length: number = 0;
    event: number = 0;
    inputFilter: string = '';
    promptText: Resource = { "id": 16777235, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" };
}
class MyDataSource extends BasicDataSource {
    private dataArray: Array<DataArray> = [
        {
            text: { "id": 16777272, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
            inputType: InputType.Normal,
            length: 15,
            event: 0,
            inputFilter: '^[A-Za-z0-9_]+$',
            promptText: { "id": 16777260, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" }
        },
        {
            text: { "id": 16777233, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
            inputType: InputType.Normal,
            length: 18,
            event: 1,
            inputFilter: '',
            promptText: { "id": 16777257, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" }
        },
        {
            text: { "id": 16777267, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
            inputType: InputType.Normal,
            length: 18,
            event: 2,
            inputFilter: '',
            promptText: { "id": 16777259, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" }
        },
        {
            text: { "id": 16777252, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
            inputType: InputType.Password,
            length: 18,
            event: 3,
            inputFilter: '',
            promptText: { "id": 16777258, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" }
        },
        {
            text: { "id": 16777229, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
            inputType: InputType.Password,
            length: 18,
            event: 4,
            inputFilter: '',
            promptText: { "id": 16777256, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" }
        }
    ];
    public totalCount() {
        return this.dataArray.length;
    }
    public getData(index: number) {
        return this.dataArray[index];
    }
    public addData(index: number) {
        this.dataArray.splice(index, 0);
        this.notifyDataAdd(index);
    }
    public pushData(index: number) {
        this.dataArray.push();
        this.notifyDataAdd(this.dataArray.length - 1);
    }
    public replaceData(result: DataArray[]) {
        this.dataArray = result;
    }
}
const TAG: string = '[RegisterInfo]';
export class RegisterInfo extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__passWord = new ObservedPropertySimplePU('', this, "passWord");
        this.__username = new ObservedPropertySimplePU('', this, "username");
        this.__emailInfo = new ObservedPropertySimplePU('', this, "emailInfo");
        this.__signature = new ObservedPropertySimplePU('', this, "signature");
        this.__confirmPassword = new ObservedPropertySimplePU('', this, "confirmPassword");
        this.__dataSet = new ObservedPropertyObjectPU(new MyDataSource(), this, "dataSet");
        this.bundleName = '';
        this.storage = new AccountData();
        this.accountModel = new AccountModel();
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: RegisterInfo_Params) {
        if (params.passWord !== undefined) {
            this.passWord = params.passWord;
        }
        if (params.username !== undefined) {
            this.username = params.username;
        }
        if (params.emailInfo !== undefined) {
            this.emailInfo = params.emailInfo;
        }
        if (params.signature !== undefined) {
            this.signature = params.signature;
        }
        if (params.confirmPassword !== undefined) {
            this.confirmPassword = params.confirmPassword;
        }
        if (params.dataSet !== undefined) {
            this.dataSet = params.dataSet;
        }
        if (params.bundleName !== undefined) {
            this.bundleName = params.bundleName;
        }
        if (params.storage !== undefined) {
            this.storage = params.storage;
        }
        if (params.accountModel !== undefined) {
            this.accountModel = params.accountModel;
        }
    }
    updateStateVars(params: RegisterInfo_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__passWord.purgeDependencyOnElmtId(rmElmtId);
        this.__username.purgeDependencyOnElmtId(rmElmtId);
        this.__emailInfo.purgeDependencyOnElmtId(rmElmtId);
        this.__signature.purgeDependencyOnElmtId(rmElmtId);
        this.__confirmPassword.purgeDependencyOnElmtId(rmElmtId);
        this.__dataSet.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__passWord.aboutToBeDeleted();
        this.__username.aboutToBeDeleted();
        this.__emailInfo.aboutToBeDeleted();
        this.__signature.aboutToBeDeleted();
        this.__confirmPassword.aboutToBeDeleted();
        this.__dataSet.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __passWord: ObservedPropertySimplePU<string>;
    get passWord() {
        return this.__passWord.get();
    }
    set passWord(newValue: string) {
        this.__passWord.set(newValue);
    }
    private __username: ObservedPropertySimplePU<string>;
    get username() {
        return this.__username.get();
    }
    set username(newValue: string) {
        this.__username.set(newValue);
    }
    private __emailInfo: ObservedPropertySimplePU<string>;
    get emailInfo() {
        return this.__emailInfo.get();
    }
    set emailInfo(newValue: string) {
        this.__emailInfo.set(newValue);
    }
    private __signature: ObservedPropertySimplePU<string>;
    get signature() {
        return this.__signature.get();
    }
    set signature(newValue: string) {
        this.__signature.set(newValue);
    }
    private __confirmPassword: ObservedPropertySimplePU<string>;
    get confirmPassword() {
        return this.__confirmPassword.get();
    }
    set confirmPassword(newValue: string) {
        this.__confirmPassword.set(newValue);
    }
    private __dataSet: ObservedPropertyObjectPU<MyDataSource>;
    get dataSet() {
        return this.__dataSet.get();
    }
    set dataSet(newValue: MyDataSource) {
        this.__dataSet.set(newValue);
    }
    private bundleName: string;
    private storage: AccountData;
    private accountModel: AccountModel;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/common/RegisterInfo.ets(166:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/common/RegisterInfo.ets(167:7)", "entry");
            Row.margin(5);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 16777223, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/common/RegisterInfo.ets(168:9)", "entry");
            Text.margin(10);
            Text.fontSize(18);
            Text.width('25%');
            Text.textAlign(TextAlign.End);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.bundleName);
            Text.debugLine("entry/src/main/ets/common/RegisterInfo.ets(173:9)", "entry");
            Text.margin(10);
            Text.width('55%');
            Text.fontSize(20);
            Text.textAlign(TextAlign.Center);
        }, Text);
        Text.pop();
        Row.pop();
        {
            const __lazyForEachItemGenFunction = (_item, index: number) => {
                const item = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/common/RegisterInfo.ets(182:9)", "entry");
                    Row.margin(5);
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item.text);
                    Text.debugLine("entry/src/main/ets/common/RegisterInfo.ets(183:11)", "entry");
                    Text.margin(10);
                    Text.fontSize(18);
                    Text.width('25%');
                    Text.textAlign(TextAlign.End);
                    Text.backgroundColor('#ffffff');
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/common/RegisterInfo.ets(189:11)", "entry");
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item.promptText);
                    Text.debugLine("entry/src/main/ets/common/RegisterInfo.ets(190:13)", "entry");
                    Text.fontSize(14);
                    Text.width('80%');
                    Text.fontColor('#ffb0b0b0');
                    Text.textAlign(TextAlign.Center);
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    TextInput.create({ placeholder: 'xxxxx' });
                    TextInput.debugLine("entry/src/main/ets/common/RegisterInfo.ets(196:13)", "entry");
                    TextInput.id('Register' + (index + 1));
                    TextInput.margin(10);
                    TextInput.width('55%');
                    TextInput.fontSize(20);
                    TextInput.maxLength(20);
                    TextInput.type(item.inputType);
                    TextInput.maxLength(item.length);
                    TextInput.inputFilter(item.inputFilter);
                    TextInput.fontWeight(FontWeight.Bold);
                    TextInput.placeholderFont({ size: 16, weight: FontWeight.Normal });
                    TextInput.onChange(async (value: string) => {
                        switch (item.event) {
                            case 0:
                                this.username = value;
                                break;
                            case 1:
                                this.emailInfo = value;
                                break;
                            case 2:
                                this.signature = value;
                                break;
                            case 3:
                                this.passWord = value;
                                break;
                            case 4:
                                this.confirmPassword = value;
                                break;
                            default:
                                break;
                        }
                    });
                }, TextInput);
                Column.pop();
                Row.pop();
            };
            const __lazyForEachItemIdFunc = (item: DataArray) => JSON.stringify(item);
            LazyForEach.create("1", this, this.dataSet, __lazyForEachItemGenFunction, __lazyForEachItemIdFunc);
            LazyForEach.pop();
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel({ "id": 16777266, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" });
            Button.debugLine("entry/src/main/ets/common/RegisterInfo.ets(233:7)", "entry");
            Button.id('complete');
            Button.margin(10);
            Button.width('60%');
            Button.fontSize(20);
            Button.fontColor(Color.White);
            Button.backgroundColor(Color.Black);
            Button.type(ButtonType.Capsule);
            Button.onClick(async () => {
                let res: RegExp = new RegExp(`^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z0-9]{2,6}`);
                let result: boolean = await this.storage.hasStorageValue(this.getUIContext().getHostContext()!, this.username, this.bundleName);
                Logger.info(TAG, `This result is ${result}`);
                if (this.username === '') {
                    this.getUIContext().showAlertDialog({
                        message: { "id": 16777225, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                        confirm: {
                            value: { "id": 16777227, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                            action: () => {
                                Logger.info(TAG, `AlertDialog enter`);
                            }
                        },
                        cancel: () => {
                            Logger.info(TAG, `AlertDialog close`);
                        }
                    });
                }
                else if (result) {
                    this.getUIContext().showAlertDialog({
                        message: { "id": 16777245, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                        confirm: {
                            value: { "id": 16777227, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                            action: () => {
                                Logger.info(TAG, `AlertDialog enter`);
                            }
                        },
                        cancel: () => {
                            Logger.info(TAG, `AlertDialog close`);
                        }
                    });
                }
                else if (this.emailInfo !== '' && !res.test(this.emailInfo)) {
                    this.getUIContext().showAlertDialog({
                        message: { "id": 16777234, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                        confirm: {
                            value: { "id": 16777227, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                            action: () => {
                                Logger.info(TAG, `AlertDialog enter`);
                            }
                        },
                        cancel: () => {
                            Logger.info(TAG, `AlertDialog close`);
                        }
                    });
                }
                else if (this.passWord === '') {
                    this.getUIContext().showAlertDialog({
                        message: { "id": 16777253, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                        confirm: {
                            value: { "id": 16777227, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                            action: () => {
                                Logger.info(TAG, `AlertDialog enter`);
                            }
                        },
                        cancel: () => {
                            Logger.info(TAG, `AlertDialog close`);
                        }
                    });
                }
                else if (this.passWord !== '' && this.passWord.length < 6) {
                    this.getUIContext().showAlertDialog({
                        message: { "id": 16777248, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                        confirm: {
                            value: { "id": 16777227, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                            action: () => {
                                Logger.info(TAG, `AlertDialog enter`);
                            }
                        },
                        cancel: () => {
                            Logger.info(TAG, `AlertDialog close`);
                        }
                    });
                }
                else if (this.confirmPassword !== this.passWord) {
                    this.getUIContext().showAlertDialog({
                        message: { "id": 16777254, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                        confirm: {
                            value: { "id": 16777227, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                            action: () => {
                                Logger.info(TAG, `AlertDialog enter`);
                            }
                        },
                        cancel: () => {
                            Logger.info(TAG, `AlertDialog close`);
                        }
                    });
                }
                else {
                    if (this.username !== '') {
                        await this.accountModel.addAccount(`${this.username}_${this.bundleName}`);
                    }
                    if (this.emailInfo !== '') {
                        await this.accountModel.setAccountCredential(`${this.username}_${this.bundleName}`, `email_${this.bundleName}`, this.emailInfo);
                    }
                    if (this.signature !== '') {
                        await this.accountModel.setAccountCredential(`${this.username}_${this.bundleName}`, `signature_${this.bundleName}`, this.signature);
                    }
                    await this.accountModel.setAssociatedData(`${this.username}_${this.bundleName}`, `key_${this.bundleName}`, this.passWord);
                    await this.storage.putStorageValue(this.getUIContext().getHostContext()!, this.username, this.passWord, this.bundleName);
                    await this.storage.putStorageValue(this.getUIContext().getHostContext()!, this.bundleName, 'true', `${this.username}_${this.bundleName}`);
                    this.getUIContext().showAlertDialog({
                        message: { "id": 16777262, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                        confirm: {
                            value: { "id": 16777227, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                            action: () => {
                                this.getUIContext().getRouter().replaceUrl({
                                    url: 'pages/Login',
                                    params: {
                                        bundleName: this.bundleName
                                    }
                                });
                            }
                        },
                        cancel: () => {
                            Logger.info(TAG, `AlertDialog close`);
                        }
                    });
                }
            });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
