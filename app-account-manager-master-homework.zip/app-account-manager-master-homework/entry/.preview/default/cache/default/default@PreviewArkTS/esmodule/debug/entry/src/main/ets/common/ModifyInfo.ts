if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ModifyInfo_Params {
    passWord?: string;
    emailInfo?: string;
    signature?: string;
    confirmPassword?: string;
    username?: string;
    bundleName?: string;
    dataSet?: MyDataSource;
    storage?: AccountData;
    accountModel?: AccountModel;
}
import Logger from "@bundle:ohos.samples.etsappaccountmanager/entry/ets/model/Logger";
import { AccountData } from "@bundle:ohos.samples.etsappaccountmanager/entry/ets/model/AccountData";
import { AccountModel } from "@bundle:ohos.samples.etsappaccountmanager/entry/ets/model/AccountModel";
import type preferences from "@ohos:data.preferences";
const TAG: string = '[ModifyInfo]';
class BasicDataSource implements IDataSource {
    private listeners: DataChangeListener[] = [];
    public totalCount() {
        return 0;
    }
    public getData(index: number): DataArray {
        return new DataArray();
    }
    registerDataChangeListener(listener: DataChangeListener) {
        if (this.listeners.indexOf(listener) < 0) {
            this.listeners.push(listener);
        }
    }
    unregisterDataChangeListener(listener: DataChangeListener) {
        const pos = this.listeners.indexOf(listener);
        if (pos >= 0) {
            this.listeners.splice(pos, 1);
        }
    }
    notifyDataReload() {
        this.listeners.forEach(listener => {
            listener.onDataReloaded();
        });
    }
    notifyDataAdd(index: number) {
        this.listeners.forEach(listener => {
            listener.onDataAdd(index);
        });
    }
    notifyDataChange(index: number) {
        this.listeners.forEach(listener => {
            listener.onDataChange(index);
        });
    }
    notifyDataDelete(index: number) {
        this.listeners.forEach(listener => {
            listener.onDataDelete(index);
        });
    }
    notifyDataMove(from: number, to: number) {
        this.listeners.forEach(listener => {
            listener.onDataMove(from, to);
        });
    }
}
class DataArray {
    text: Resource = { "id": 16777235, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" };
    inputType: InputType = InputType.Normal;
    length: number = 0;
    event: number = 0;
    promptText: Resource = { "id": 16777235, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" };
}
class MyDataSource extends BasicDataSource {
    private dataArray: Array<DataArray> = [
        {
            text: { "id": 16777233, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
            inputType: InputType.Normal,
            length: 18,
            event: 0,
            promptText: { "id": 16777257, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" }
        },
        {
            text: { "id": 16777267, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
            inputType: InputType.Normal,
            length: 18,
            event: 1,
            promptText: { "id": 16777259, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" }
        },
        {
            text: { "id": 16777270, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
            inputType: InputType.Password,
            length: 18,
            event: 2,
            promptText: { "id": 16777258, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" }
        },
        {
            text: { "id": 16777269, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
            inputType: InputType.Password,
            length: 18,
            event: 3,
            promptText: { "id": 16777256, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" }
        }
    ];
    public totalCount() {
        return this.dataArray.length;
    }
    public getData(index: number) {
        return this.dataArray[index];
    }
    public addData(index: number) {
        this.dataArray.splice(index, 0);
        this.notifyDataAdd(index);
    }
    public pushData(index: number) {
        this.dataArray.push();
        this.notifyDataAdd(this.dataArray.length - 1);
    }
    public replaceData(result: Array<DataArray>) {
        this.dataArray = result;
    }
}
export class ModifyInfo extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__passWord = new ObservedPropertySimplePU('', this, "passWord");
        this.__emailInfo = new ObservedPropertySimplePU('', this, "emailInfo");
        this.__signature = new ObservedPropertySimplePU('', this, "signature");
        this.__confirmPassword = new ObservedPropertySimplePU('', this, "confirmPassword");
        this.__username = new SynchedPropertySimpleOneWayPU(params.username, this, "username");
        this.__bundleName = new SynchedPropertySimpleOneWayPU(params.bundleName, this, "bundleName");
        this.__dataSet = new ObservedPropertyObjectPU(new MyDataSource(), this, "dataSet");
        this.storage = new AccountData();
        this.accountModel = new AccountModel();
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ModifyInfo_Params) {
        if (params.passWord !== undefined) {
            this.passWord = params.passWord;
        }
        if (params.emailInfo !== undefined) {
            this.emailInfo = params.emailInfo;
        }
        if (params.signature !== undefined) {
            this.signature = params.signature;
        }
        if (params.confirmPassword !== undefined) {
            this.confirmPassword = params.confirmPassword;
        }
        if (params.dataSet !== undefined) {
            this.dataSet = params.dataSet;
        }
        if (params.storage !== undefined) {
            this.storage = params.storage;
        }
        if (params.accountModel !== undefined) {
            this.accountModel = params.accountModel;
        }
    }
    updateStateVars(params: ModifyInfo_Params) {
        this.__username.reset(params.username);
        this.__bundleName.reset(params.bundleName);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__passWord.purgeDependencyOnElmtId(rmElmtId);
        this.__emailInfo.purgeDependencyOnElmtId(rmElmtId);
        this.__signature.purgeDependencyOnElmtId(rmElmtId);
        this.__confirmPassword.purgeDependencyOnElmtId(rmElmtId);
        this.__username.purgeDependencyOnElmtId(rmElmtId);
        this.__bundleName.purgeDependencyOnElmtId(rmElmtId);
        this.__dataSet.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__passWord.aboutToBeDeleted();
        this.__emailInfo.aboutToBeDeleted();
        this.__signature.aboutToBeDeleted();
        this.__confirmPassword.aboutToBeDeleted();
        this.__username.aboutToBeDeleted();
        this.__bundleName.aboutToBeDeleted();
        this.__dataSet.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __passWord: ObservedPropertySimplePU<string>;
    get passWord() {
        return this.__passWord.get();
    }
    set passWord(newValue: string) {
        this.__passWord.set(newValue);
    }
    private __emailInfo: ObservedPropertySimplePU<string>;
    get emailInfo() {
        return this.__emailInfo.get();
    }
    set emailInfo(newValue: string) {
        this.__emailInfo.set(newValue);
    }
    private __signature: ObservedPropertySimplePU<string>;
    get signature() {
        return this.__signature.get();
    }
    set signature(newValue: string) {
        this.__signature.set(newValue);
    }
    private __confirmPassword: ObservedPropertySimplePU<string>;
    get confirmPassword() {
        return this.__confirmPassword.get();
    }
    set confirmPassword(newValue: string) {
        this.__confirmPassword.set(newValue);
    }
    private __username: SynchedPropertySimpleOneWayPU<string>;
    get username() {
        return this.__username.get();
    }
    set username(newValue: string) {
        this.__username.set(newValue);
    }
    private __bundleName: SynchedPropertySimpleOneWayPU<string>;
    get bundleName() {
        return this.__bundleName.get();
    }
    set bundleName(newValue: string) {
        this.__bundleName.set(newValue);
    }
    private __dataSet: ObservedPropertyObjectPU<MyDataSource>;
    get dataSet() {
        return this.__dataSet.get();
    }
    set dataSet(newValue: MyDataSource) {
        this.__dataSet.set(newValue);
    }
    private storage: AccountData;
    private accountModel: AccountModel;
    async getInfo(value: string, name: string, credentialType: string) {
        try {
            value = await this.accountModel.getAccountCredential(name, credentialType);
            Logger.info(TAG, `getAccountCredential email is ${value}`);
        }
        catch (err) {
            Logger.info(TAG, `getAccountCredential failed err is ${JSON.stringify(err)}`);
        }
        return value;
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/common/ModifyInfo.ets(164:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/common/ModifyInfo.ets(165:7)", "entry");
            Row.margin(5);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 16777223, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/common/ModifyInfo.ets(166:9)", "entry");
            Text.margin(10);
            Text.fontSize(18);
            Text.width('25%');
            Text.textAlign(TextAlign.End);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.bundleName);
            Text.debugLine("entry/src/main/ets/common/ModifyInfo.ets(171:9)", "entry");
            Text.margin(20);
            Text.width('55%');
            Text.fontSize(20);
            Text.textAlign(TextAlign.Start);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/common/ModifyInfo.ets(179:7)", "entry");
            Row.margin(5);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 16777271, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/common/ModifyInfo.ets(180:9)", "entry");
            Text.margin(10);
            Text.fontSize(18);
            Text.width('25%');
            Text.textAlign(TextAlign.End);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.username);
            Text.debugLine("entry/src/main/ets/common/ModifyInfo.ets(185:9)", "entry");
            Text.margin(10);
            Text.width('55%');
            Text.fontSize(20);
            Text.textAlign(TextAlign.Start);
        }, Text);
        Text.pop();
        Row.pop();
        {
            const __lazyForEachItemGenFunction = (_item, index: number) => {
                const item = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/common/ModifyInfo.ets(194:9)", "entry");
                    Row.margin(5);
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item.text);
                    Text.debugLine("entry/src/main/ets/common/ModifyInfo.ets(195:11)", "entry");
                    Text.margin(10);
                    Text.fontSize(18);
                    Text.width('25%');
                    Text.textAlign(TextAlign.End);
                    Text.backgroundColor('#ffffff');
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/common/ModifyInfo.ets(201:11)", "entry");
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item.promptText);
                    Text.debugLine("entry/src/main/ets/common/ModifyInfo.ets(202:13)", "entry");
                    Text.fontSize(14);
                    Text.width('80%');
                    Text.fontColor('#ffb0b0b0');
                    Text.textAlign(TextAlign.Center);
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    TextInput.create({ placeholder: 'xxxxx' });
                    TextInput.debugLine("entry/src/main/ets/common/ModifyInfo.ets(208:13)", "entry");
                    TextInput.id('Modify' + (index + 1));
                    TextInput.margin(10);
                    TextInput.width('55%');
                    TextInput.fontSize(20);
                    TextInput.maxLength(20);
                    TextInput.type(item.inputType);
                    TextInput.maxLength(item.length);
                    TextInput.fontWeight(FontWeight.Bold);
                    TextInput.placeholderFont({ size: 16, weight: FontWeight.Normal });
                    TextInput.onChange(async (value: string) => {
                        switch (item.event) {
                            case 0:
                                this.emailInfo = value;
                                break;
                            case 1:
                                this.signature = value;
                                break;
                            case 2:
                                this.passWord = value;
                                break;
                            case 3:
                                this.confirmPassword = value;
                                break;
                            default:
                                break;
                        }
                    });
                }, TextInput);
                Column.pop();
                Row.pop();
            };
            const __lazyForEachItemIdFunc = (item: DataArray) => JSON.stringify(item);
            LazyForEach.create("1", this, this.dataSet, __lazyForEachItemGenFunction, __lazyForEachItemIdFunc);
            LazyForEach.pop();
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel({ "id": 16777266, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" });
            Button.debugLine("entry/src/main/ets/common/ModifyInfo.ets(241:7)", "entry");
            Button.id('modComplete');
            Button.margin(10);
            Button.width('60%');
            Button.fontSize(20);
            Button.fontColor(Color.White);
            Button.type(ButtonType.Capsule);
            Button.onClick(async () => {
                if (this.emailInfo !== '') {
                    await this.accountModel.setAccountCredential(`${this.username}_${this.bundleName}`, `email_${this.bundleName}`, this.emailInfo);
                }
                if (this.signature !== '') {
                    await this.accountModel.setAccountCredential(`${this.username}_${this.bundleName}`, `signature_${this.bundleName}`, this.signature);
                }
                let res: RegExp = new RegExp(`^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z0-9]{2,6}$`);
                let userPassWord: preferences.ValueType = await this.storage.getStorageValue(this.getUIContext().getHostContext()!, this.username, this.bundleName);
                if (this.emailInfo !== '' && !res.test(this.emailInfo)) {
                    this.getUIContext().showAlertDialog({
                        message: { "id": 16777234, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                        confirm: {
                            value: { "id": 16777227, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                            action: () => {
                                this.emailInfo = '';
                            }
                        },
                        cancel: () => {
                            Logger.info(TAG, `AlertDialog close`);
                        }
                    });
                }
                else if (this.passWord !== '' && this.passWord.length < 6) {
                    this.getUIContext().showAlertDialog({
                        message: { "id": 16777248, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                        confirm: {
                            value: { "id": 16777227, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                            action: () => {
                                Logger.info(TAG, `AlertDialog enter`);
                            }
                        },
                        cancel: () => {
                            Logger.info(TAG, `AlertDialog close`);
                        }
                    });
                }
                else if (this.passWord !== '' && this.passWord === userPassWord) {
                    this.getUIContext().showAlertDialog({
                        message: { "id": 16777273, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                        confirm: {
                            value: { "id": 16777227, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                            action: () => {
                                Logger.info(TAG, `AlertDialog enter`);
                            }
                        },
                        cancel: () => {
                            Logger.info(TAG, `AlertDialog close`);
                        }
                    });
                }
                else if (this.confirmPassword !== this.passWord) {
                    this.getUIContext().showAlertDialog({
                        message: { "id": 16777254, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                        confirm: {
                            value: { "id": 16777227, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                            action: () => {
                                Logger.info(TAG, `AlertDialog enter`);
                            }
                        },
                        cancel: () => {
                            Logger.info(TAG, `AlertDialog close`);
                        }
                    });
                }
                else if (this.passWord !== '' && this.confirmPassword !== '') {
                    await this.storage.putStorageValue(this.getUIContext().getHostContext()!, this.username, this.passWord, this.bundleName);
                    let email = await this.getInfo('', `${this.username}_${this.bundleName}`, `email_${this.bundleName}`);
                    let signature = await this.getInfo('', `${this.username}_${this.bundleName}`, `signature_${this.bundleName}`);
                    this.getUIContext().showAlertDialog({
                        message: { "id": 16777250, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                        confirm: {
                            value: { "id": 16777227, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                            action: () => {
                                this.getUIContext().getRouter().replaceUrl({
                                    url: 'pages/Account',
                                    params: {
                                        email: email,
                                        signature: signature,
                                        bundleName: this.bundleName,
                                        username: this.username
                                    }
                                });
                            }
                        },
                        cancel: () => {
                            Logger.info(TAG, `AlertDialog close`);
                        }
                    });
                }
                else {
                    let email = await this.getInfo('', `${this.username}_${this.bundleName}`, `email_${this.bundleName}`);
                    let signature = await this.getInfo('', `${this.username}_${this.bundleName}`, `signature_${this.bundleName}`);
                    this.getUIContext().showAlertDialog({
                        message: { "id": 16777250, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                        confirm: {
                            value: { "id": 16777227, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                            action: () => {
                                this.getUIContext().getRouter().replaceUrl({
                                    url: 'pages/Account',
                                    params: {
                                        email: email,
                                        signature: signature,
                                        bundleName: this.bundleName,
                                        username: this.username
                                    }
                                });
                            }
                        },
                        cancel: () => {
                            Logger.info(TAG, `AlertDialog close`);
                        }
                    });
                }
            });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
