if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface LoginInfo_Params {
    name?: string;
    password?: string;
    bundleName?: string;
    storage?: AccountData;
    accountModel?: AccountModel;
}
import Logger from "@bundle:ohos.samples.etsappaccountmanager/entry/ets/model/Logger";
import { AccountData } from "@bundle:ohos.samples.etsappaccountmanager/entry/ets/model/AccountData";
import { AccountModel } from "@bundle:ohos.samples.etsappaccountmanager/entry/ets/model/AccountModel";
import type preferences from "@ohos:data.preferences";
const TAG: string = '[LoginInfo]';
export class LoginInfo extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__name = new ObservedPropertySimplePU('', this, "name");
        this.__password = new ObservedPropertySimplePU('', this, "password");
        this.__bundleName = new SynchedPropertySimpleOneWayPU(params.bundleName, this, "bundleName");
        this.storage = new AccountData();
        this.accountModel = new AccountModel();
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: LoginInfo_Params) {
        if (params.name !== undefined) {
            this.name = params.name;
        }
        if (params.password !== undefined) {
            this.password = params.password;
        }
        if (params.storage !== undefined) {
            this.storage = params.storage;
        }
        if (params.accountModel !== undefined) {
            this.accountModel = params.accountModel;
        }
    }
    updateStateVars(params: LoginInfo_Params) {
        this.__bundleName.reset(params.bundleName);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__name.purgeDependencyOnElmtId(rmElmtId);
        this.__password.purgeDependencyOnElmtId(rmElmtId);
        this.__bundleName.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__name.aboutToBeDeleted();
        this.__password.aboutToBeDeleted();
        this.__bundleName.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __name: ObservedPropertySimplePU<string>;
    get name() {
        return this.__name.get();
    }
    set name(newValue: string) {
        this.__name.set(newValue);
    }
    private __password: ObservedPropertySimplePU<string>;
    get password() {
        return this.__password.get();
    }
    set password(newValue: string) {
        this.__password.set(newValue);
    }
    private __bundleName: SynchedPropertySimpleOneWayPU<string>;
    get bundleName() {
        return this.__bundleName.get();
    }
    set bundleName(newValue: string) {
        this.__bundleName.set(newValue);
    }
    private storage: AccountData;
    private accountModel: AccountModel;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/common/LoginInfo.ets(32:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/common/LoginInfo.ets(33:7)", "entry");
            Row.margin({ top: '10%' });
            Row.padding({ left: 5 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 16777223, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/common/LoginInfo.ets(34:9)", "entry");
            Text.margin(10);
            Text.fontSize(18);
            Text.width('20%');
            Text.textAlign(TextAlign.End);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.bundleName);
            Text.debugLine("entry/src/main/ets/common/LoginInfo.ets(39:9)", "entry");
            Text.margin(10);
            Text.width('55%');
            Text.fontSize(20);
            Text.textAlign(TextAlign.Center);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/common/LoginInfo.ets(48:7)", "entry");
            Row.padding({ left: 5 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 16777272, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/common/LoginInfo.ets(49:9)", "entry");
            Text.margin(10);
            Text.fontSize(18);
            Text.width('20%');
            Text.textAlign(TextAlign.End);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: 'xxxxxxx' });
            TextInput.debugLine("entry/src/main/ets/common/LoginInfo.ets(55:9)", "entry");
            TextInput.id('nameInput');
            TextInput.margin(10);
            TextInput.width('55%');
            TextInput.fontSize(20);
            TextInput.maxLength(20);
            TextInput.fontWeight(FontWeight.Bold);
            TextInput.placeholderFont({ size: 16, weight: FontWeight.Normal });
            TextInput.onChange((value: string) => {
                this.name = value;
            });
        }, TextInput);
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/common/LoginInfo.ets(69:7)", "entry");
            Row.padding({ left: 5 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 16777252, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/common/LoginInfo.ets(70:9)", "entry");
            Text.margin(10);
            Text.fontSize(18);
            Text.width('20%');
            Text.textAlign(TextAlign.End);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: 'xxxxxxx' });
            TextInput.debugLine("entry/src/main/ets/common/LoginInfo.ets(76:9)", "entry");
            TextInput.id('passwordInput');
            TextInput.margin(10);
            TextInput.width('55%');
            TextInput.fontSize(20);
            TextInput.maxLength(20);
            TextInput.type(InputType.Password);
            TextInput.fontWeight(FontWeight.Bold);
            TextInput.placeholderFont({ size: 16, weight: FontWeight.Normal });
            TextInput.onChange((value: string) => {
                this.password = value;
            });
        }, TextInput);
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel({ "id": 16777261, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" });
            Button.debugLine("entry/src/main/ets/common/LoginInfo.ets(91:7)", "entry");
            Button.id('register');
            Button.margin(10);
            Button.width('60%');
            Button.fontSize(20);
            Button.fontColor(Color.White);
            Button.backgroundColor(Color.Black);
            Button.type(ButtonType.Capsule);
            Button.onClick(() => {
                this.getUIContext().getRouter().replaceUrl({
                    url: 'pages/Register',
                    params: {
                        bundleName: this.bundleName
                    }
                });
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel({ "id": 16777246, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" });
            Button.debugLine("entry/src/main/ets/common/LoginInfo.ets(108:7)", "entry");
            Button.id('login');
            Button.margin(10);
            Button.width('60%');
            Button.fontSize(20);
            Button.fontColor(Color.White);
            Button.backgroundColor(Color.Black);
            Button.type(ButtonType.Capsule);
            Button.onClick(async () => {
                let result: preferences.ValueType = await this.storage.getStorageValue(this.getUIContext().getHostContext()!, this.name, this.bundleName);
                let effect: preferences.ValueType = await this.storage.getStorageValue(this.getUIContext().getHostContext()!, this.bundleName, `${this.name}_${this.bundleName}`);
                if (this.name === '') {
                    this.getUIContext().showAlertDialog({
                        message: { "id": 16777225, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                        confirm: {
                            value: { "id": 16777227, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                            action: () => {
                                Logger.info(TAG, `AlertDialog enter`);
                            }
                        },
                        cancel: () => {
                            Logger.info(TAG, `AlertDialog close`);
                        }
                    });
                }
                else if (this.password === '') {
                    this.getUIContext().showAlertDialog({
                        message: { "id": 16777253, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                        confirm: {
                            value: { "id": 16777227, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                            action: () => {
                                Logger.info(TAG, `AlertDialog enter`);
                            }
                        },
                        cancel: () => {
                            Logger.info(TAG, `AlertDialog close`);
                        }
                    });
                }
                else if (result === this.password && effect === 'true') {
                    let email: string = '';
                    let signature: string = '';
                    try {
                        email = await this.accountModel.getAccountCredential(`${this.name}_${this.bundleName}`, `email_${this.bundleName}`);
                        Logger.info(TAG, `getAccountCredential email is ${email}`);
                    }
                    catch (err) {
                        email = '';
                        Logger.info(TAG, `getAccountCredential failed err is ${JSON.stringify(err)}`);
                    }
                    try {
                        signature = await this.accountModel.getAccountCredential(`${this.name}_${this.bundleName}`, `signature_${this.bundleName}`);
                        Logger.info(TAG, `getAccountCredential signature is ${signature}`);
                    }
                    catch (err) {
                        signature = '';
                        Logger.info(TAG, `getAccountCredential failed err is ${JSON.stringify(err)}`);
                    }
                    this.getUIContext().getRouter().replaceUrl({
                        url: 'pages/Account',
                        params: {
                            email: email,
                            username: this.name,
                            signature: signature,
                            bundleName: this.bundleName
                        }
                    });
                }
                else {
                    this.getUIContext().showAlertDialog({
                        message: { "id": 16777255, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                        confirm: {
                            value: { "id": 16777227, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                            action: () => {
                                Logger.info(TAG, `AlertDialog enter`);
                            }
                        },
                        cancel: () => {
                            Logger.info(TAG, `AlertDialog close`);
                        }
                    });
                }
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel({ "id": 16777237, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" });
            Button.debugLine("entry/src/main/ets/common/LoginInfo.ets(190:7)", "entry");
            Button.id('findPassword');
            Button.margin(10);
            Button.width('60%');
            Button.fontSize(20);
            Button.fontColor(Color.Blue);
            Button.backgroundColor(Color.White);
            Button.type(ButtonType.Capsule);
            Button.onClick(() => {
                this.getUIContext().getRouter().replaceUrl({
                    url: 'pages/FindPassword',
                    params: {
                        bundleName: this.bundleName
                    }
                });
            });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
