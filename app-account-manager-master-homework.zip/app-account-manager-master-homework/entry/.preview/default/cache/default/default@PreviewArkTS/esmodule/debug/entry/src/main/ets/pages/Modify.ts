if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Modify_Params {
    username?: string;
    bundleName?: string;
    email?: string;
    signature?: string;
}
import { ModifyInfo } from "@bundle:ohos.samples.etsappaccountmanager/entry/ets/common/ModifyInfo";
import { NavigationBar } from "@bundle:ohos.samples.etsappaccountmanager/entry/ets/common/NavigationBar";
class Modify extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__username = new ObservedPropertySimplePU((this.getUIContext().getRouter().getParams() as Record<string, string>)['username'], this, "username");
        this.__bundleName = new ObservedPropertySimplePU((this.getUIContext().getRouter().getParams() as Record<string, string>)['bundleName'], this, "bundleName");
        this.__email = new ObservedPropertySimplePU((this.getUIContext().getRouter().getParams() as Record<string, string>)['email'], this, "email");
        this.__signature = new ObservedPropertySimplePU((this.getUIContext().getRouter().getParams() as Record<string, string>)['signature'], this, "signature");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Modify_Params) {
        if (params.username !== undefined) {
            this.username = params.username;
        }
        if (params.bundleName !== undefined) {
            this.bundleName = params.bundleName;
        }
        if (params.email !== undefined) {
            this.email = params.email;
        }
        if (params.signature !== undefined) {
            this.signature = params.signature;
        }
    }
    updateStateVars(params: Modify_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__username.purgeDependencyOnElmtId(rmElmtId);
        this.__bundleName.purgeDependencyOnElmtId(rmElmtId);
        this.__email.purgeDependencyOnElmtId(rmElmtId);
        this.__signature.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__username.aboutToBeDeleted();
        this.__bundleName.aboutToBeDeleted();
        this.__email.aboutToBeDeleted();
        this.__signature.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __username: ObservedPropertySimplePU<string>;
    get username() {
        return this.__username.get();
    }
    set username(newValue: string) {
        this.__username.set(newValue);
    }
    private __bundleName: ObservedPropertySimplePU<string>;
    get bundleName() {
        return this.__bundleName.get();
    }
    set bundleName(newValue: string) {
        this.__bundleName.set(newValue);
    }
    private __email: ObservedPropertySimplePU<string>;
    get email() {
        return this.__email.get();
    }
    set email(newValue: string) {
        this.__email.set(newValue);
    }
    private __signature: ObservedPropertySimplePU<string>;
    get signature() {
        return this.__signature.get();
    }
    set signature(newValue: string) {
        this.__signature.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/Modify.ets(28:5)", "entry");
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Modify.ets(29:7)", "entry");
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavigationBar(this, {
                        title: { "id": 16777249, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                        flag: true,
                        url: 'pages/Account',
                        username: this.username,
                        bundleName: this.bundleName,
                        email: this.email,
                        signature: this.signature
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Modify.ets", line: 30, col: 9 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: { "id": 16777249, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                            flag: true,
                            url: 'pages/Account',
                            username: this.username,
                            bundleName: this.bundleName,
                            email: this.email,
                            signature: this.signature
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "NavigationBar" });
        }
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new ModifyInfo(this, { bundleName: this.bundleName, username: this.username }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Modify.ets", line: 40, col: 9 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            bundleName: this.bundleName,
                            username: this.username
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        bundleName: this.bundleName, username: this.username
                    });
                }
            }, { name: "ModifyInfo" });
        }
        Column.pop();
        Scroll.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Modify";
    }
}
registerNamedRoute(() => new Modify(undefined, {}), "", { bundleName: "ohos.samples.etsappaccountmanager", moduleName: "entry", pagePath: "pages/Modify", pageFullPath: "entry/src/main/ets/pages/Modify", integratedHsp: "false", moduleType: "followWithHap" });
