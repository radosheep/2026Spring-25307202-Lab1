if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Account_Params {
    email?: string;
    username?: string;
    signature?: string;
    bundleName?: string;
}
import { AccountInfo } from "@bundle:ohos.samples.etsappaccountmanager/entry/ets/common/AccountInfo";
import { NavigationBar } from "@bundle:ohos.samples.etsappaccountmanager/entry/ets/common/NavigationBar";
class Account extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__email = new ObservedPropertySimplePU((this.getUIContext().getRouter().getParams() as Record<string, string>)['email'], this, "email");
        this.__username = new ObservedPropertySimplePU((this.getUIContext().getRouter().getParams() as Record<string, string>)['username'], this, "username");
        this.__signature = new ObservedPropertySimplePU((this.getUIContext().getRouter().getParams() as Record<string, string>)['signature'], this, "signature");
        this.__bundleName = new ObservedPropertySimplePU((this.getUIContext().getRouter().getParams() as Record<string, string>)['bundleName'], this, "bundleName");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Account_Params) {
        if (params.email !== undefined) {
            this.email = params.email;
        }
        if (params.username !== undefined) {
            this.username = params.username;
        }
        if (params.signature !== undefined) {
            this.signature = params.signature;
        }
        if (params.bundleName !== undefined) {
            this.bundleName = params.bundleName;
        }
    }
    updateStateVars(params: Account_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__email.purgeDependencyOnElmtId(rmElmtId);
        this.__username.purgeDependencyOnElmtId(rmElmtId);
        this.__signature.purgeDependencyOnElmtId(rmElmtId);
        this.__bundleName.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__email.aboutToBeDeleted();
        this.__username.aboutToBeDeleted();
        this.__signature.aboutToBeDeleted();
        this.__bundleName.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __email: ObservedPropertySimplePU<string>;
    get email() {
        return this.__email.get();
    }
    set email(newValue: string) {
        this.__email.set(newValue);
    }
    private __username: ObservedPropertySimplePU<string>;
    get username() {
        return this.__username.get();
    }
    set username(newValue: string) {
        this.__username.set(newValue);
    }
    private __signature: ObservedPropertySimplePU<string>;
    get signature() {
        return this.__signature.get();
    }
    set signature(newValue: string) {
        this.__signature.set(newValue);
    }
    private __bundleName: ObservedPropertySimplePU<string>;
    get bundleName() {
        return this.__bundleName.get();
    }
    set bundleName(newValue: string) {
        this.__bundleName.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Account.ets(29:5)", "entry");
            Column.width('100%');
            Column.height('100%');
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new NavigationBar(this, { title: { "id": 16777221, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" }, flag: false }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Account.ets", line: 30, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            title: { "id": 16777221, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                            flag: false
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "NavigationBar" });
        }
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new AccountInfo(this, {
                        email: this.email,
                        username: this.username,
                        signature: this.signature,
                        bundleName: this.bundleName
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Account.ets", line: 32, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            email: this.email,
                            username: this.username,
                            signature: this.signature,
                            bundleName: this.bundleName
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        email: this.email,
                        username: this.username,
                        signature: this.signature,
                        bundleName: this.bundleName
                    });
                }
            }, { name: "AccountInfo" });
        }
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Account";
    }
}
registerNamedRoute(() => new Account(undefined, {}), "", { bundleName: "ohos.samples.etsappaccountmanager", moduleName: "entry", pagePath: "pages/Account", pageFullPath: "entry/src/main/ets/pages/Account", integratedHsp: "false", moduleType: "followWithHap" });
