if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface BundleInfo_Params {
    dataSet?: MyDataSource;
}
/*
 * Copyright (c) 2022 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class BasicDataSource implements IDataSource {
    private listeners: DataChangeListener[] = [];
    public totalCount() {
        return 0;
    }
    public getData(index: number): DataArray {
        return new DataArray();
    }
    registerDataChangeListener(listener: DataChangeListener) {
        if (this.listeners.indexOf(listener) < 0) {
            this.listeners.push(listener);
        }
    }
    unregisterDataChangeListener(listener: DataChangeListener) {
        const pos = this.listeners.indexOf(listener);
        if (pos >= 0) {
            this.listeners.splice(pos, 1);
        }
    }
    notifyDataReload() {
        this.listeners.forEach(listener => {
            listener.onDataReloaded();
        });
    }
    notifyDataAdd(index: number) {
        this.listeners.forEach(listener => {
            listener.onDataAdd(index);
        });
    }
    notifyDataChange(index: number) {
        this.listeners.forEach(listener => {
            listener.onDataChange(index);
        });
    }
    notifyDataDelete(index: number) {
        this.listeners.forEach(listener => {
            listener.onDataDelete(index);
        });
    }
    notifyDataMove(from: number, to: number) {
        this.listeners.forEach(listener => {
            listener.onDataMove(from, to);
        });
    }
}
class DataArray {
    img: Resource = { "id": 16777235, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" };
    text: Resource = { "id": 16777235, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" };
    name: string = '';
}
class MyDataSource extends BasicDataSource {
    private dataArray: Array<DataArray> = [
        { img: { "id": 16777220, "type": 20000, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" }, text: { "id": 16777251, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" }, name: 'Music' },
        { img: { "id": 16777278, "type": 20000, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" }, text: { "id": 16777274, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" }, name: 'Video' },
        { img: { "id": 16777219, "type": 20000, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" }, text: { "id": 16777247, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" }, name: 'Map' }
    ];
    public totalCount() {
        return this.dataArray.length;
    }
    public getData(index: number) {
        return this.dataArray[index];
    }
    public addData(index: number) {
        this.dataArray.splice(index, 0);
        this.notifyDataAdd(index);
    }
    public pushData(index: number) {
        this.dataArray.push();
        this.notifyDataAdd(this.dataArray.length - 1);
    }
    public replaceData(result: DataArray[]) {
        this.dataArray = result;
    }
}
export class BundleInfo extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__dataSet = new ObservedPropertyObjectPU(new MyDataSource(), this, "dataSet");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: BundleInfo_Params) {
        if (params.dataSet !== undefined) {
            this.dataSet = params.dataSet;
        }
    }
    updateStateVars(params: BundleInfo_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__dataSet.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__dataSet.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __dataSet: ObservedPropertyObjectPU<MyDataSource>;
    get dataSet() {
        return this.__dataSet.get();
    }
    set dataSet(newValue: MyDataSource) {
        this.__dataSet.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/common/BundleInfo.ets(113:5)", "entry");
            Column.layoutWeight(1);
        }, Column);
        {
            const __lazyForEachItemGenFunction = _item => {
                const item = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/common/BundleInfo.ets(115:9)", "entry");
                    Row.id(item.name + 'App');
                    Row.margin(5);
                    Row.width('95%');
                    Row.height('20%');
                    Row.borderRadius(20);
                    Row.backgroundColor('#f6f6f6');
                    Row.onClick(() => {
                        this.getUIContext().getRouter().replaceUrl({
                            url: 'pages/Login',
                            params: {
                                bundleName: item.name
                            }
                        });
                    });
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create(item.img);
                    Image.debugLine("entry/src/main/ets/common/BundleInfo.ets(116:11)", "entry");
                    Image.margin(10);
                    Image.width('40%');
                    Image.height('60%');
                    Image.objectFit(ImageFit.Contain);
                }, Image);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item.text);
                    Text.debugLine("entry/src/main/ets/common/BundleInfo.ets(122:11)", "entry");
                    Text.margin(10);
                    Text.fontSize(20);
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create({ "id": 16777218, "type": 20000, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/common/BundleInfo.ets(126:11)", "entry");
                    Image.margin(10);
                    Image.width('15%');
                    Image.height('20%');
                    Image.layoutWeight(1);
                    Image.objectFit(ImageFit.Contain);
                }, Image);
                Row.pop();
            };
            const __lazyForEachItemIdFunc = (item: DataArray) => item.name.toString();
            LazyForEach.create("1", this, this.dataSet, __lazyForEachItemGenFunction, __lazyForEachItemIdFunc);
            LazyForEach.pop();
        }
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
