if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface AccountInfo_Params {
    email?: string;
    username?: string;
    signature?: string;
    bundleName?: string;
    storage?: AccountData;
    accountModel?: AccountModel;
}
import Logger from "@bundle:ohos.samples.etsappaccountmanager/entry/ets/model/Logger";
import { AccountData } from "@bundle:ohos.samples.etsappaccountmanager/entry/ets/model/AccountData";
import { AccountModel } from "@bundle:ohos.samples.etsappaccountmanager/entry/ets/model/AccountModel";
const TAG: string = '[AccountInfo]';
export class AccountInfo extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__email = new SynchedPropertySimpleOneWayPU(params.email, this, "email");
        this.__username = new SynchedPropertySimpleOneWayPU(params.username, this, "username");
        this.__signature = new SynchedPropertySimpleOneWayPU(params.signature, this, "signature");
        this.__bundleName = new SynchedPropertySimpleOneWayPU(params.bundleName, this, "bundleName");
        this.storage = new AccountData();
        this.accountModel = new AccountModel();
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: AccountInfo_Params) {
        if (params.storage !== undefined) {
            this.storage = params.storage;
        }
        if (params.accountModel !== undefined) {
            this.accountModel = params.accountModel;
        }
    }
    updateStateVars(params: AccountInfo_Params) {
        this.__email.reset(params.email);
        this.__username.reset(params.username);
        this.__signature.reset(params.signature);
        this.__bundleName.reset(params.bundleName);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__email.purgeDependencyOnElmtId(rmElmtId);
        this.__username.purgeDependencyOnElmtId(rmElmtId);
        this.__signature.purgeDependencyOnElmtId(rmElmtId);
        this.__bundleName.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__email.aboutToBeDeleted();
        this.__username.aboutToBeDeleted();
        this.__signature.aboutToBeDeleted();
        this.__bundleName.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __email: SynchedPropertySimpleOneWayPU<string>;
    get email() {
        return this.__email.get();
    }
    set email(newValue: string) {
        this.__email.set(newValue);
    }
    private __username: SynchedPropertySimpleOneWayPU<string>;
    get username() {
        return this.__username.get();
    }
    set username(newValue: string) {
        this.__username.set(newValue);
    }
    private __signature: SynchedPropertySimpleOneWayPU<string>;
    get signature() {
        return this.__signature.get();
    }
    set signature(newValue: string) {
        this.__signature.set(newValue);
    }
    private __bundleName: SynchedPropertySimpleOneWayPU<string>;
    get bundleName() {
        return this.__bundleName.get();
    }
    set bundleName(newValue: string) {
        this.__bundleName.set(newValue);
    }
    private storage: AccountData;
    private accountModel: AccountModel;
    infoShow(title: Resource, value: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/common/AccountInfo.ets(32:5)", "entry");
            Row.padding({ left: 5 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(title);
            Text.debugLine("entry/src/main/ets/common/AccountInfo.ets(33:7)", "entry");
            Text.margin(10);
            Text.fontSize(18);
            Text.width('25%');
            Text.textAlign(TextAlign.End);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(value);
            Text.debugLine("entry/src/main/ets/common/AccountInfo.ets(38:7)", "entry");
            Text.margin(10);
            Text.width('55%');
            Text.fontSize(20);
            Text.textAlign(TextAlign.Start);
        }, Text);
        Text.pop();
        Row.pop();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/common/AccountInfo.ets(48:5)", "entry");
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/common/AccountInfo.ets(49:7)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.layoutWeight(1);
        }, Column);
        this.infoShow.bind(this)({ "id": 16777223, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" }, this.bundleName);
        this.infoShow.bind(this)({ "id": 16777271, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" }, this.username);
        this.infoShow.bind(this)({ "id": 16777233, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" }, this.email);
        this.infoShow.bind(this)({ "id": 16777267, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" }, this.signature);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel({ "id": 16777249, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" });
            Button.debugLine("entry/src/main/ets/common/AccountInfo.ets(55:9)", "entry");
            Button.id('modify');
            Button.margin(10);
            Button.width('60%');
            Button.fontSize(20);
            Button.fontColor(Color.White);
            Button.type(ButtonType.Capsule);
            Button.onClick(() => {
                this.getUIContext().getRouter().replaceUrl({
                    url: 'pages/Modify',
                    params: {
                        username: this.username,
                        bundleName: this.bundleName,
                        email: this.email,
                        signature: this.signature
                    }
                });
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel({ "id": 16777222, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" });
            Button.debugLine("entry/src/main/ets/common/AccountInfo.ets(74:9)", "entry");
            Button.id('application');
            Button.margin(10);
            Button.width('60%');
            Button.fontSize(20);
            Button.fontColor(Color.White);
            Button.type(ButtonType.Capsule);
            Button.onClick(() => {
                this.getUIContext().showAlertDialog({
                    title: { "id": 16777275, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                    message: { "id": 16777268, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                    primaryButton: {
                        value: { "id": 16777228, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                        action: () => {
                            this.getUIContext().getRouter().replaceUrl({
                                url: 'pages/Index'
                            });
                        }
                    },
                    secondaryButton: {
                        value: { "id": 16777226, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                        action: () => {
                            Logger.info(TAG, `AlertDialog enter`);
                        }
                    },
                    cancel: () => {
                        Logger.info(TAG, `AlertDialog close`);
                    }
                });
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel({ "id": 16777230, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" });
            Button.debugLine("entry/src/main/ets/common/AccountInfo.ets(106:9)", "entry");
            Button.id('delete');
            Button.margin(10);
            Button.width('60%');
            Button.fontSize(20);
            Button.fontColor(Color.White);
            Button.type(ButtonType.Capsule);
            Button.onClick(() => {
                this.getUIContext().showAlertDialog({
                    title: { "id": 16777275, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                    message: { "id": 16777231, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                    primaryButton: {
                        value: { "id": 16777228, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                        action: () => {
                            this.accountModel.deleteAccount(`${this.username}_${this.bundleName}`);
                            this.storage.deleteStorageValue(this.getUIContext().getHostContext()!, this.username, this.bundleName);
                            this.getUIContext().getRouter().replaceUrl({
                                url: 'pages/Login',
                                params: {
                                    bundleName: this.bundleName
                                }
                            });
                        }
                    },
                    secondaryButton: {
                        value: { "id": 16777226, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                        action: () => {
                            Logger.info(TAG, `AlertDialog enter`);
                        }
                    },
                    cancel: () => {
                        Logger.info(TAG, `AlertDialog close`);
                    }
                });
            });
        }, Button);
        Button.pop();
        Column.pop();
        Scroll.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
