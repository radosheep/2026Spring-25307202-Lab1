import Logger from "@bundle:ohos.samples.etsappaccountmanager/entry/ets/model/Logger";
import appAccount from "@ohos:account.appAccount";
import type { BusinessError } from "@ohos:base";
const TAG: string = '[AccountModel]';
const app: appAccount.AppAccountManager = appAccount.createAppAccountManager();
export class AccountModel {
    async addAccount(username: string) {
        try {
            await app.createAccount(username);
            Logger.info(TAG, `addAccount success`);
        }
        catch (error) {
            let err = error as BusinessError;
            Logger.error(TAG, `createAccount failed, error code=${err.code}, message=${err.message}`);
        }
        return;
    }
    async deleteAccount(username: string) {
        try {
            await app.removeAccount(username);
            Logger.info(TAG, `deleteAccount success`);
        }
        catch (error) {
            let err = error as BusinessError;
            Logger.error(TAG, `removeAccount failed, error code=${err.code}, message=${err.message}`);
        }
        return;
    }
    async setAccountCredential(username: string, credentialType: string, credential: string) {
        try {
            await app.setCredential(username, credentialType, credential);
            Logger.info(TAG, `setAccountCredential success`);
        }
        catch (error) {
            let err = error as BusinessError;
            Logger.error(TAG, `setCredential failed, error code=${err.code}, message=${err.message}`);
        }
        return;
    }
    async setAssociatedData(name: string, key: string, value: string) {
        try {
            await app.setCustomData(name, key, value);
            Logger.info(TAG, `setAssociatedData success`);
        }
        catch (error) {
            let err = error as BusinessError;
            Logger.error(TAG, `setCustomData failed, error code=${err.code}, message=${err.message}`);
        }
        return;
    }
    async getAccountCredential(name: string, credentialType: string) {
        let result = '';
        try {
            result = await app.getCredential(name, credentialType);
            Logger.info(TAG, `getAccountCredential success`);
        }
        catch (error) {
            let err = error as BusinessError;
            Logger.error(TAG, `getCredential failed, error code=${err.code}, message=${err.message}`);
        }
        return result;
    }
    async getAssociatedData(name: string, key: string) {
        let result = '';
        try {
            result = await app.getCustomData(name, key);
            Logger.info(TAG, `getAssociatedData success`);
        }
        catch (error) {
            let err = error as BusinessError;
            Logger.error(TAG, `getCustomData failed, error code=${err.code}, message=${err.message}`);
        }
        return result;
    }
}
