if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface FindPasswordInfo_Params {
    email?: string;
    verifyCode?: string;
}
import Logger from "@bundle:ohos.samples.etsappaccountmanager/entry/ets/model/Logger";
const TAG: string = '[FindPasswordInfo]';
export class FindPasswordInfo extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__email = new ObservedPropertySimplePU('', this, "email");
        this.__verifyCode = new ObservedPropertySimplePU('', this, "verifyCode");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: FindPasswordInfo_Params) {
        if (params.email !== undefined) {
            this.email = params.email;
        }
        if (params.verifyCode !== undefined) {
            this.verifyCode = params.verifyCode;
        }
    }
    updateStateVars(params: FindPasswordInfo_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__email.purgeDependencyOnElmtId(rmElmtId);
        this.__verifyCode.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__email.aboutToBeDeleted();
        this.__verifyCode.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __email: ObservedPropertySimplePU<string>;
    get email() {
        return this.__email.get();
    }
    set email(newValue: string) {
        this.__email.set(newValue);
    }
    private __verifyCode: ObservedPropertySimplePU<string>;
    get verifyCode() {
        return this.__verifyCode.get();
    }
    set verifyCode(newValue: string) {
        this.__verifyCode.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/common/FindPasswordInfo.ets(26:5)", "entry");
            Column.width('100%');
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 邮箱输入框
            Row.create();
            Row.debugLine("entry/src/main/ets/common/FindPasswordInfo.ets(28:7)", "entry");
            // 邮箱输入框
            Row.padding({ left: 5 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 16777241, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/common/FindPasswordInfo.ets(29:9)", "entry");
            Text.margin(10);
            Text.fontSize(18);
            Text.width('20%');
            Text.textAlign(TextAlign.End);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: 'example@email.com' });
            TextInput.debugLine("entry/src/main/ets/common/FindPasswordInfo.ets(35:9)", "entry");
            TextInput.id('emailInput');
            TextInput.margin(10);
            TextInput.width('55%');
            TextInput.fontSize(20);
            TextInput.maxLength(30);
            TextInput.fontWeight(FontWeight.Bold);
            TextInput.placeholderFont({ size: 16, weight: FontWeight.Normal });
            TextInput.onChange((value: string) => {
                this.email = value;
            });
        }, TextInput);
        // 邮箱输入框
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 验证码输入框
            Row.create();
            Row.debugLine("entry/src/main/ets/common/FindPasswordInfo.ets(50:7)", "entry");
            // 验证码输入框
            Row.padding({ left: 5 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 16777238, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/common/FindPasswordInfo.ets(51:9)", "entry");
            Text.margin(10);
            Text.fontSize(18);
            Text.width('20%');
            Text.textAlign(TextAlign.End);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: 'xxxxxx' });
            TextInput.debugLine("entry/src/main/ets/common/FindPasswordInfo.ets(57:9)", "entry");
            TextInput.id('verifyCodeInput');
            TextInput.margin(10);
            TextInput.width('55%');
            TextInput.fontSize(20);
            TextInput.maxLength(6);
            TextInput.fontWeight(FontWeight.Bold);
            TextInput.placeholderFont({ size: 16, weight: FontWeight.Normal });
            TextInput.type(InputType.Normal);
            TextInput.onChange((value: string) => {
                this.verifyCode = value;
            });
        }, TextInput);
        // 验证码输入框
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 两个并列居中的按钮
            Row.create();
            Row.debugLine("entry/src/main/ets/common/FindPasswordInfo.ets(73:7)", "entry");
            // 两个并列居中的按钮
            Row.width('100%');
            // 两个并列居中的按钮
            Row.justifyContent(FlexAlign.Center);
            // 两个并列居中的按钮
            Row.margin({ top: 20 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel({ "id": 16777265, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" });
            Button.debugLine("entry/src/main/ets/common/FindPasswordInfo.ets(74:9)", "entry");
            Button.id('sendCode');
            Button.margin({ left: 10, right: 10 });
            Button.width('40%');
            Button.fontSize(16);
            Button.fontColor(Color.White);
            Button.backgroundColor(Color.Black);
            Button.type(ButtonType.Capsule);
            Button.onClick(() => {
                Logger.info(TAG, `Send verify code to email: ${this.email}`);
                // 发送验证码逻辑
                if (this.email === '') {
                    this.getUIContext().showAlertDialog({
                        message: { "id": 16777242, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                        confirm: {
                            value: { "id": 16777227, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                            action: () => {
                                Logger.info(TAG, `AlertDialog close`);
                            }
                        }
                    });
                }
                else {
                    this.getUIContext().showAlertDialog({
                        message: { "id": 16777240, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                        confirm: {
                            value: { "id": 16777227, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                            action: () => {
                                Logger.info(TAG, `AlertDialog close`);
                            }
                        }
                    });
                }
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel({ "id": 16777228, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" });
            Button.debugLine("entry/src/main/ets/common/FindPasswordInfo.ets(108:9)", "entry");
            Button.id('confirmCode');
            Button.margin({ left: 10, right: 10 });
            Button.width('40%');
            Button.fontSize(16);
            Button.fontColor(Color.White);
            Button.backgroundColor(Color.Black);
            Button.type(ButtonType.Capsule);
            Button.onClick(() => {
                Logger.info(TAG, `Verify code: ${this.verifyCode}`);
                // 验证码确认逻辑
                if (this.verifyCode === '') {
                    this.getUIContext().showAlertDialog({
                        message: { "id": 16777239, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                        confirm: {
                            value: { "id": 16777227, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                            action: () => {
                                Logger.info(TAG, `AlertDialog close`);
                            }
                        }
                    });
                }
                else {
                    this.getUIContext().showAlertDialog({
                        message: { "id": 16777243, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                        confirm: {
                            value: { "id": 16777227, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                            action: () => {
                                Logger.info(TAG, `AlertDialog close`);
                            }
                        }
                    });
                }
            });
        }, Button);
        Button.pop();
        // 两个并列居中的按钮
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
