if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface NavigationBar_Params {
    url?: string;
    username?: string;
    bundleName?: string;
    flag?: boolean;
    title?: Resource;
    email?: string;
    signature?: string;
}
import Logger from "@bundle:ohos.samples.etsappaccountmanager/entry/ets/model/Logger";
const TAG: string = '[NavigationBar]';
export class NavigationBar extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.url = '';
        this.username = '';
        this.bundleName = '';
        this.flag = false;
        this.title = { "id": 16777235, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" };
        this.email = '';
        this.signature = '';
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: NavigationBar_Params) {
        if (params.url !== undefined) {
            this.url = params.url;
        }
        if (params.username !== undefined) {
            this.username = params.username;
        }
        if (params.bundleName !== undefined) {
            this.bundleName = params.bundleName;
        }
        if (params.flag !== undefined) {
            this.flag = params.flag;
        }
        if (params.title !== undefined) {
            this.title = params.title;
        }
        if (params.email !== undefined) {
            this.email = params.email;
        }
        if (params.signature !== undefined) {
            this.signature = params.signature;
        }
    }
    updateStateVars(params: NavigationBar_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private url: string;
    private username: string;
    private bundleName: string;
    private flag: boolean;
    private title: Resource;
    private email: string;
    private signature: string;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/common/NavigationBar.ets(31:5)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.flag) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/common/NavigationBar.ets(33:9)", "entry");
                        Row.height('8%');
                        Row.width('100%');
                        Row.padding({ left: 15 });
                        Row.backgroundColor('#0D9FFB');
                        Row.constraintSize({ minHeight: 50 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/common/NavigationBar.ets(34:11)", "entry");
                        Row.id('back');
                        Row.layoutWeight(1);
                        Row.onClick(() => {
                            this.getUIContext().showAlertDialog({
                                title: { "id": 16777275, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                                message: { "id": 16777264, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                                primaryButton: {
                                    value: { "id": 16777228, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                                    action: () => {
                                        this.getUIContext().getRouter().replaceUrl({
                                            url: this.url,
                                            params: {
                                                bundleName: this.bundleName,
                                                username: this.username,
                                                email: this.email,
                                                signature: this.signature
                                            }
                                        });
                                    }
                                },
                                secondaryButton: {
                                    value: { "id": 16777226, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" },
                                    action: () => {
                                        Logger.info(TAG, `AlertDialog enter`);
                                    }
                                },
                                cancel: () => {
                                    Logger.info(TAG, `AlertDialog close`);
                                }
                            });
                        });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create({ "id": 16777276, "type": 20000, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" });
                        Image.debugLine("entry/src/main/ets/common/NavigationBar.ets(35:13)", "entry");
                        Image.objectFit(ImageFit.Contain);
                        Image.width('10%');
                    }, Image);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create({ "id": 16777224, "type": 10003, params: [], "bundleName": "ohos.samples.etsappaccountmanager", "moduleName": "entry" });
                        Text.debugLine("entry/src/main/ets/common/NavigationBar.ets(38:13)", "entry");
                        Text.fontSize(18);
                        Text.textAlign(TextAlign.End);
                        Text.fontColor(Color.White);
                    }, Text);
                    Text.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.title);
                        Text.debugLine("entry/src/main/ets/common/NavigationBar.ets(76:11)", "entry");
                        Text.fontSize(18);
                        Text.fontColor(Color.White);
                        Text.textAlign(TextAlign.Start);
                        Text.margin({ right: '5%' });
                    }, Text);
                    Text.pop();
                    Row.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/common/NavigationBar.ets(88:9)", "entry");
                        Row.height('8%');
                        Row.width('100%');
                        Row.padding({ left: 15 });
                        Row.backgroundColor('#0D9FFB');
                        Row.constraintSize({ minHeight: 50 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.title);
                        Text.debugLine("entry/src/main/ets/common/NavigationBar.ets(89:11)", "entry");
                        Text.fontSize(18);
                        Text.fontColor(Color.White);
                        Text.textAlign(TextAlign.Center);
                    }, Text);
                    Text.pop();
                    Row.pop();
                });
            }
        }, If);
        If.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
