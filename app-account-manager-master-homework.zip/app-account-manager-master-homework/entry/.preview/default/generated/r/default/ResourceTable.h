/*
 * Copyright (c) 2023 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef RESOURCE_TABLE_H
#define RESOURCE_TABLE_H

#include<stdint.h>

namespace OHOS {
const int32_t STRING_ACCOUNT = 0x01000005;
const int32_t STRING_APP_NAME = 0x01000000;
const int32_t STRING_APPLICATION = 0x01000006;
const int32_t STRING_APPNAME = 0x01000007;
const int32_t STRING_BACK = 0x01000008;
const int32_t STRING_BLANK = 0x01000009;
const int32_t STRING_CANCEL = 0x0100000a;
const int32_t STRING_CLOSE = 0x0100000b;
const int32_t STRING_CONFIRM = 0x0100000c;
const int32_t STRING_CONFIRM_PASSWORD = 0x0100000d;
const int32_t STRING_DELETE = 0x0100000e;
const int32_t STRING_DELETE_ACCOUNT = 0x0100000f;
const int32_t STRING_DESCRIPTION_MAINABILITY = 0x01000010;
const int32_t STRING_EMAIL = 0x01000011;
const int32_t STRING_EMAILINFO = 0x01000012;
const int32_t STRING_EMPTY = 0x01000013;
const int32_t STRING_ENTRY_MAINABILITY = 0x01000014;
const int32_t STRING_FIND_PASSWORD = 0x01000015;
const int32_t STRING_FIND_PASSWORD_CODE = 0x01000016;
const int32_t STRING_FIND_PASSWORD_CODE_EMPTY = 0x01000017;
const int32_t STRING_FIND_PASSWORD_CODE_SENT = 0x01000018;
const int32_t STRING_FIND_PASSWORD_EMAIL = 0x01000019;
const int32_t STRING_FIND_PASSWORD_EMAIL_EMPTY = 0x0100001a;
const int32_t STRING_FIND_PASSWORD_SUCCESS = 0x0100001b;
const int32_t STRING_FIND_PASSWORD_TITLE = 0x0100001c;
const int32_t STRING_HAS = 0x0100001d;
const int32_t STRING_LOGIN = 0x0100001e;
const int32_t STRING_MAP = 0x0100001f;
const int32_t STRING_MIN_PASSWORD = 0x01000020;
const int32_t STRING_MODIFY = 0x01000021;
const int32_t STRING_MODIFY_INFO = 0x01000022;
const int32_t STRING_MUSIC = 0x01000023;
const int32_t STRING_PASSWORD = 0x01000024;
const int32_t STRING_PASSWORD_BLANK = 0x01000025;
const int32_t STRING_PASSWORD_ERROR = 0x01000026;
const int32_t STRING_PASSWORD_MESSAGE = 0x01000027;
const int32_t STRING_PROMPT_CONFIRM_PASSWORD = 0x01000028;
const int32_t STRING_PROMPT_EMAIL = 0x01000029;
const int32_t STRING_PROMPT_PASSWORD = 0x0100002a;
const int32_t STRING_PROMPT_SIGNATURE = 0x0100002b;
const int32_t STRING_PROMPT_USERNAME = 0x0100002c;
const int32_t STRING_REGISTER = 0x0100002d;
const int32_t STRING_REGISTER_INFO = 0x0100002e;
const int32_t STRING_REGISTER_LOGIN = 0x0100002f;
const int32_t STRING_ROUTERBACK = 0x01000030;
const int32_t STRING_SEND_CODE = 0x01000031;
const int32_t STRING_SETTING = 0x01000032;
const int32_t STRING_SIGNATURE = 0x01000033;
const int32_t STRING_SWITCH_APP = 0x01000034;
const int32_t STRING_UNCONFIRM_PASSWORD = 0x01000035;
const int32_t STRING_UNPASSWORD = 0x01000036;
const int32_t STRING_UNUSERNAME = 0x01000037;
const int32_t STRING_USERNAME = 0x01000038;
const int32_t STRING_USERPASSWORD = 0x01000039;
const int32_t STRING_VIDEO = 0x0100003a;
const int32_t STRING_WARNING = 0x0100003b;
const int32_t COLOR_START_WINDOW_BACKGROUND = 0x0100003d;
const int32_t MEDIA_APP_ICON = 0x01000001;
const int32_t MEDIA_ICON = 0x01000040;
const int32_t MEDIA_LEFT = 0x0100003c;
const int32_t MEDIA_MAP = 0x01000003;
const int32_t MEDIA_MUSIC = 0x01000004;
const int32_t MEDIA_RIGHT = 0x01000002;
const int32_t MEDIA_VIDEO = 0x0100003e;
const int32_t PROFILE_MAIN_PAGES = 0x0100003f;
}
#endif